type token =
  | EOF
  | LPAR
  | RPAR
  | COMMA
  | BAR
  | BBAR
  | ARROW
  | DARROW
  | EQUAL
  | ARROWEQ
  | ID of (Lexing.position * string)
  | DIGITS of (Lexing.position * string)
  | COLON of (Lexing.position * string)
  | STRING of (string)
  | OTHER of (string)
  | CONTEXTSENSITIVE of (Lexing.position)
  | EQUATIONS of (Lexing.position)
  | INNERMOST of (Lexing.position)
  | RULES of (Lexing.position)
  | STRATEGY of (Lexing.position)
  | THEORY of (Lexing.position)
  | VAR of (Lexing.position)
  | OUTERMOST of (Lexing.position)

open Parsing;;
let _ = parse_error;;
# 2 "trs_parser.mly"

  open Trs_ast

# 33 "trs_parser.ml"
let yytransl_const = [|
    0 (* EOF *);
  257 (* LPAR *);
  258 (* RPAR *);
  259 (* COMMA *);
  260 (* BAR *);
  261 (* BBAR *);
  262 (* ARROW *);
  263 (* DARROW *);
  264 (* EQUAL *);
  265 (* ARROWEQ *);
    0|]

let yytransl_block = [|
  266 (* ID *);
  267 (* DIGITS *);
  268 (* COLON *);
  269 (* STRING *);
  270 (* OTHER *);
  271 (* CONTEXTSENSITIVE *);
  272 (* EQUATIONS *);
  273 (* INNERMOST *);
  274 (* RULES *);
  275 (* STRATEGY *);
  276 (* THEORY *);
  277 (* VAR *);
  278 (* OUTERMOST *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\002\000\002\000\002\000\002\000\002\000\007\000\
\007\000\007\000\007\000\007\000\007\000\007\000\007\000\007\000\
\007\000\007\000\007\000\003\000\003\000\008\000\008\000\008\000\
\008\000\008\000\008\000\008\000\008\000\008\000\008\000\008\000\
\004\000\004\000\009\000\009\000\010\000\010\000\011\000\005\000\
\005\000\013\000\013\000\013\000\013\000\014\000\014\000\016\000\
\016\000\015\000\015\000\017\000\017\000\017\000\017\000\012\000\
\012\000\012\000\018\000\018\000\006\000\006\000\006\000\019\000\
\019\000\020\000\020\000\000\000"

let yylen = "\002\000\
\004\000\001\000\002\000\002\000\002\000\002\000\002\000\000\000\
\002\000\002\000\002\000\002\000\002\000\004\000\002\000\002\000\
\002\000\002\000\002\000\000\000\002\000\001\000\001\000\001\000\
\001\000\001\000\001\000\001\000\001\000\001\000\001\000\001\000\
\000\000\004\000\002\000\002\000\000\000\002\000\003\000\000\000\
\002\000\003\000\005\000\003\000\003\000\001\000\003\000\003\000\
\003\000\003\000\005\000\001\000\003\000\003\000\005\000\001\000\
\003\000\004\000\001\000\003\000\001\000\001\000\002\000\000\000\
\005\000\000\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\002\000\000\000\068\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\022\000\000\000\000\000\000\000\000\000\025\000\026\000\
\027\000\029\000\030\000\031\000\032\000\028\000\007\000\000\000\
\023\000\024\000\005\000\000\000\000\000\000\000\000\000\061\000\
\062\000\006\000\000\000\004\000\003\000\000\000\000\000\000\000\
\015\000\019\000\017\000\016\000\018\000\010\000\011\000\012\000\
\013\000\009\000\000\000\000\000\000\000\041\000\000\000\063\000\
\000\000\000\000\000\000\021\000\001\000\000\000\057\000\000\000\
\000\000\000\000\000\000\044\000\045\000\000\000\035\000\036\000\
\000\000\000\000\000\000\014\000\000\000\058\000\000\000\000\000\
\000\000\000\000\000\000\038\000\000\000\034\000\060\000\000\000\
\000\000\043\000\000\000\000\000\000\000\050\000\067\000\000\000\
\039\000\000\000\000\000\000\000\000\000\000\000\000\000\065\000\
\051\000\048\000\049\000\047\000\000\000\054\000\000\000\055\000"

let yydgoto = "\002\000\
\005\000\011\000\045\000\044\000\035\000\042\000\031\000\036\000\
\067\000\080\000\081\000\101\000\038\000\098\000\076\000\099\000\
\102\000\073\000\064\000\091\000"

let yysindex = "\003\000\
\001\000\000\000\000\000\014\255\000\000\103\255\030\000\008\255\
\005\255\030\000\020\255\103\255\103\255\103\255\103\255\103\255\
\103\255\000\000\103\255\103\255\103\255\103\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\103\255\
\000\000\000\000\000\000\035\255\255\254\030\000\047\255\000\000\
\000\000\000\000\039\255\000\000\000\000\030\000\001\000\054\255\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\189\255\043\000\030\000\000\000\030\000\000\000\
\030\000\030\000\056\255\000\000\000\000\103\255\000\000\058\255\
\061\255\052\255\022\255\000\000\000\000\030\000\000\000\000\000\
\030\000\057\255\005\255\000\000\030\000\000\000\030\000\030\000\
\056\000\030\000\064\255\000\000\030\000\000\000\000\000\063\255\
\044\255\000\000\066\255\059\255\065\255\000\000\000\000\047\255\
\000\000\056\000\030\000\030\000\030\000\030\000\056\000\000\000\
\000\000\000\000\000\000\000\000\067\255\000\000\056\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\071\255\074\255\000\000\
\075\255\077\255\000\000\071\255\071\255\071\255\071\255\071\255\
\071\255\000\000\071\255\071\255\071\255\071\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\071\255\
\000\000\000\000\000\000\168\255\000\000\074\255\080\255\000\000\
\000\000\000\000\000\000\000\000\000\000\077\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\077\255\081\255\000\000\000\000\000\000\071\255\000\000\082\255\
\000\000\125\255\210\255\000\000\000\000\083\255\000\000\000\000\
\081\255\000\000\075\255\000\000\000\000\000\000\000\000\000\000\
\000\000\083\255\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\231\255\147\255\252\255\000\000\000\000\080\255\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\017\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\041\000\000\000\212\255\006\000\052\000\000\000\025\000\253\255\
\000\000\010\000\000\000\249\255\000\000\239\255\000\000\000\000\
\165\255\008\000\246\255\007\000"

let yytablesize = 334
let yytable = "\037\000\
\003\000\068\000\032\000\001\000\060\000\043\000\046\000\061\000\
\032\000\032\000\032\000\032\000\032\000\032\000\113\000\032\000\
\032\000\032\000\032\000\118\000\079\000\047\000\039\000\006\000\
\040\000\088\000\089\000\120\000\032\000\041\000\037\000\007\000\
\008\000\009\000\010\000\059\000\048\000\049\000\050\000\051\000\
\052\000\053\000\046\000\054\000\055\000\056\000\057\000\063\000\
\065\000\107\000\108\000\072\000\075\000\077\000\066\000\070\000\
\058\000\083\000\082\000\078\000\085\000\046\000\086\000\087\000\
\093\000\104\000\032\000\106\000\109\000\111\000\110\000\119\000\
\008\000\082\000\090\000\040\000\033\000\072\000\020\000\096\000\
\097\000\064\000\037\000\059\000\066\000\105\000\090\000\069\000\
\094\000\062\000\092\000\116\000\095\000\112\000\084\000\000\000\
\103\000\000\000\000\000\114\000\115\000\097\000\117\000\012\000\
\000\000\013\000\014\000\000\000\015\000\000\000\016\000\017\000\
\018\000\019\000\020\000\021\000\022\000\023\000\024\000\025\000\
\026\000\027\000\028\000\029\000\030\000\023\000\023\000\000\000\
\023\000\023\000\000\000\000\000\000\000\000\000\023\000\023\000\
\000\000\000\000\000\000\023\000\023\000\023\000\023\000\023\000\
\023\000\023\000\023\000\023\000\023\000\000\000\000\000\023\000\
\000\000\000\000\000\000\000\000\023\000\023\000\000\000\000\000\
\000\000\023\000\023\000\023\000\023\000\023\000\023\000\023\000\
\023\000\056\000\056\000\056\000\056\000\056\000\056\000\056\000\
\056\000\056\000\056\000\056\000\000\000\000\000\056\000\056\000\
\056\000\056\000\056\000\056\000\056\000\056\000\071\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\018\000\033\000\
\034\000\000\000\000\000\023\000\024\000\025\000\026\000\027\000\
\028\000\029\000\030\000\042\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\042\000\042\000\042\000\000\000\000\000\
\042\000\042\000\042\000\042\000\042\000\042\000\042\000\042\000\
\046\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\046\000\046\000\046\000\000\000\000\000\046\000\046\000\046\000\
\046\000\046\000\046\000\046\000\046\000\052\000\000\000\000\000\
\000\000\004\000\000\000\000\000\000\000\052\000\052\000\052\000\
\000\000\000\000\052\000\052\000\052\000\052\000\052\000\052\000\
\052\000\052\000\053\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\053\000\053\000\053\000\000\000\000\000\053\000\
\053\000\053\000\053\000\053\000\053\000\053\000\053\000\018\000\
\033\000\034\000\000\000\000\000\023\000\024\000\025\000\026\000\
\027\000\028\000\029\000\030\000\018\000\074\000\034\000\000\000\
\000\000\023\000\024\000\025\000\026\000\027\000\028\000\029\000\
\030\000\018\000\100\000\034\000\000\000\000\000\023\000\024\000\
\025\000\026\000\027\000\028\000\029\000\030\000"

let yycheck = "\007\000\
\000\000\046\000\006\000\001\000\006\001\001\001\010\000\009\001\
\012\000\013\000\014\000\015\000\016\000\017\000\106\000\019\000\
\020\000\021\000\022\000\111\000\065\000\002\001\015\001\010\001\
\017\001\004\001\005\001\119\000\032\000\022\001\038\000\018\001\
\019\001\020\001\021\001\001\001\012\000\013\000\014\000\015\000\
\016\000\017\000\046\000\019\000\020\000\021\000\022\000\001\001\
\010\001\006\001\007\001\059\000\060\000\061\000\016\001\002\001\
\032\000\002\001\066\000\063\000\003\001\065\000\002\001\012\001\
\008\001\002\001\070\000\005\001\003\001\005\001\012\001\005\001\
\002\001\081\000\078\000\002\001\002\001\085\000\002\001\087\000\
\088\000\002\001\002\001\002\001\002\001\093\000\090\000\047\000\
\083\000\038\000\081\000\109\000\085\000\104\000\070\000\255\255\
\090\000\255\255\255\255\107\000\108\000\109\000\110\000\001\001\
\255\255\003\001\004\001\255\255\006\001\255\255\008\001\009\001\
\010\001\011\001\012\001\013\001\014\001\015\001\016\001\017\001\
\018\001\019\001\020\001\021\001\022\001\001\001\002\001\255\255\
\004\001\005\001\255\255\255\255\255\255\255\255\010\001\011\001\
\255\255\255\255\255\255\015\001\016\001\017\001\018\001\019\001\
\020\001\021\001\022\001\001\001\002\001\255\255\255\255\005\001\
\255\255\255\255\255\255\255\255\010\001\011\001\255\255\255\255\
\255\255\015\001\016\001\017\001\018\001\019\001\020\001\021\001\
\022\001\002\001\003\001\004\001\005\001\006\001\007\001\008\001\
\009\001\010\001\011\001\012\001\255\255\255\255\015\001\016\001\
\017\001\018\001\019\001\020\001\021\001\022\001\002\001\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\010\001\011\001\
\012\001\255\255\255\255\015\001\016\001\017\001\018\001\019\001\
\020\001\021\001\022\001\002\001\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\010\001\011\001\012\001\255\255\255\255\
\015\001\016\001\017\001\018\001\019\001\020\001\021\001\022\001\
\002\001\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\010\001\011\001\012\001\255\255\255\255\015\001\016\001\017\001\
\018\001\019\001\020\001\021\001\022\001\002\001\255\255\255\255\
\255\255\001\001\255\255\255\255\255\255\010\001\011\001\012\001\
\255\255\255\255\015\001\016\001\017\001\018\001\019\001\020\001\
\021\001\022\001\002\001\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\010\001\011\001\012\001\255\255\255\255\015\001\
\016\001\017\001\018\001\019\001\020\001\021\001\022\001\010\001\
\011\001\012\001\255\255\255\255\015\001\016\001\017\001\018\001\
\019\001\020\001\021\001\022\001\010\001\011\001\012\001\255\255\
\255\255\015\001\016\001\017\001\018\001\019\001\020\001\021\001\
\022\001\010\001\011\001\012\001\255\255\255\255\015\001\016\001\
\017\001\018\001\019\001\020\001\021\001\022\001"

let yynames_const = "\
  EOF\000\
  LPAR\000\
  RPAR\000\
  COMMA\000\
  BAR\000\
  BBAR\000\
  ARROW\000\
  DARROW\000\
  EQUAL\000\
  ARROWEQ\000\
  "

let yynames_block = "\
  ID\000\
  DIGITS\000\
  COLON\000\
  STRING\000\
  OTHER\000\
  CONTEXTSENSITIVE\000\
  EQUATIONS\000\
  INNERMOST\000\
  RULES\000\
  STRATEGY\000\
  THEORY\000\
  VAR\000\
  OUTERMOST\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'decl) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 :  Trs_ast.decl list ) in
    Obj.repr(
# 18 "trs_parser.mly"
                        ( _2::_4 )
# 272 "trs_parser.ml"
               :  Trs_ast.decl list ))
; (fun __caml_parser_env ->
    Obj.repr(
# 19 "trs_parser.mly"
              ( [] )
# 278 "trs_parser.ml"
               :  Trs_ast.decl list ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'idlist) in
    Obj.repr(
# 23 "trs_parser.mly"
                        ( VarDecl(_2) )
# 286 "trs_parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'listofthdecl) in
    Obj.repr(
# 24 "trs_parser.mly"
                        ( TheoryDecl(_2) )
# 294 "trs_parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'listofrules) in
    Obj.repr(
# 25 "trs_parser.mly"
                        ( RulesDecl(_2) )
# 302 "trs_parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'strategydecl) in
    Obj.repr(
# 26 "trs_parser.mly"
                        ( StrategyDecl(_2) )
# 310 "trs_parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 27 "trs_parser.mly"
                        ( OtherDecl(_1,_2) )
# 318 "trs_parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 31 "trs_parser.mly"
                            ( [] )
# 324 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'id) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 32 "trs_parser.mly"
                            ( snd _1 :: _2 )
# 332 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 33 "trs_parser.mly"
                            ( snd _1 :: _2 )
# 340 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 34 "trs_parser.mly"
                            ( snd _1 :: _2 )
# 348 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 35 "trs_parser.mly"
                            ( _1::_2 )
# 356 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 36 "trs_parser.mly"
                            ( _1::_2 )
# 364 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'anylist) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 37 "trs_parser.mly"
                            ( ("("::_2) @ (")"::_4) )
# 372 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 38 "trs_parser.mly"
                            ( ","::_2 )
# 379 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 39 "trs_parser.mly"
                            ( "="::_2 )
# 386 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 40 "trs_parser.mly"
                            ( "->"::_2 )
# 393 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 41 "trs_parser.mly"
                              ( "->="::_2 )
# 400 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'anylist) in
    Obj.repr(
# 42 "trs_parser.mly"
                            ( "|"::_2 )
# 407 "trs_parser.ml"
               : 'anylist))
; (fun __caml_parser_env ->
    Obj.repr(
# 46 "trs_parser.mly"
                ( [] )
# 413 "trs_parser.ml"
               : 'idlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'id) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'idlist) in
    Obj.repr(
# 47 "trs_parser.mly"
                ( _1::_2 )
# 421 "trs_parser.ml"
               : 'idlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position * string) in
    Obj.repr(
# 51 "trs_parser.mly"
                   ( _1 )
# 428 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position * string) in
    Obj.repr(
# 52 "trs_parser.mly"
                   ( _1 )
# 435 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position * string) in
    Obj.repr(
# 53 "trs_parser.mly"
                   ( _1 )
# 442 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 54 "trs_parser.mly"
                   ( _1,"CONTEXTSENSITIVE" )
# 449 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 55 "trs_parser.mly"
                   ( _1,"EQUATIONS" )
# 456 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 56 "trs_parser.mly"
                   ( _1,"INNERMOST" )
# 463 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 57 "trs_parser.mly"
                   ( _1,"OUTERMOST" )
# 470 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 58 "trs_parser.mly"
                   ( _1,"RULES" )
# 477 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 59 "trs_parser.mly"
                   ( _1,"STRATEGY" )
# 484 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 60 "trs_parser.mly"
                   ( _1,"THEORY" )
# 491 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 61 "trs_parser.mly"
                   ( _1,"VAR" )
# 498 "trs_parser.ml"
               : 'id))
; (fun __caml_parser_env ->
    Obj.repr(
# 66 "trs_parser.mly"
                                ( [] )
# 504 "trs_parser.ml"
               : 'listofthdecl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'thdecl) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'listofthdecl) in
    Obj.repr(
# 67 "trs_parser.mly"
                                ( _2::_4 )
# 512 "trs_parser.ml"
               : 'listofthdecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'idlist) in
    Obj.repr(
# 71 "trs_parser.mly"
            ( Builtin(_1,_2) )
# 520 "trs_parser.ml"
               : 'thdecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'eqlist) in
    Obj.repr(
# 72 "trs_parser.mly"
                   ( Equations(_2) )
# 528 "trs_parser.ml"
               : 'thdecl))
; (fun __caml_parser_env ->
    Obj.repr(
# 76 "trs_parser.mly"
                     ( [] )
# 534 "trs_parser.ml"
               : 'eqlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'equation) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'eqlist) in
    Obj.repr(
# 77 "trs_parser.mly"
                     ( _1::_2 )
# 542 "trs_parser.ml"
               : 'eqlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 81 "trs_parser.mly"
                     ( (_1,_3) )
# 550 "trs_parser.ml"
               : 'equation))
; (fun __caml_parser_env ->
    Obj.repr(
# 85 "trs_parser.mly"
                     ( [] )
# 556 "trs_parser.ml"
               : 'listofrules))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'rule) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'listofrules) in
    Obj.repr(
# 86 "trs_parser.mly"
                     ( _1::_2 )
# 564 "trs_parser.ml"
               : 'listofrules))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 90 "trs_parser.mly"
                                   ( Rew([],_1,_3) )
# 572 "trs_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'condlist) in
    Obj.repr(
# 91 "trs_parser.mly"
                                   ( Rew(_5,_1,_3) )
# 581 "trs_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'distrib) in
    Obj.repr(
# 92 "trs_parser.mly"
                                   ( DistRew(_1,_3) )
# 589 "trs_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 93 "trs_parser.mly"
                                     ( RelRew([],_1,_3) )
# 597 "trs_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'cond) in
    Obj.repr(
# 100 "trs_parser.mly"
                         ( [_1] )
# 604 "trs_parser.ml"
               : 'condlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'cond) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'condlist) in
    Obj.repr(
# 101 "trs_parser.mly"
                         ( _1::_3 )
# 612 "trs_parser.ml"
               : 'condlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 105 "trs_parser.mly"
                    ( Arrow(_1,_3) )
# 620 "trs_parser.ml"
               : 'cond))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 106 "trs_parser.mly"
                    ( Darrow(_1,_3) )
# 628 "trs_parser.ml"
               : 'cond))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'distrib0) in
    Obj.repr(
# 110 "trs_parser.mly"
                     ( (1,_1)::_3 )
# 636 "trs_parser.ml"
               : 'distrib))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : Lexing.position * string) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'distrib0) in
    Obj.repr(
# 111 "trs_parser.mly"
                                  ( (int_of_string (snd _1),_3)::_5 )
# 646 "trs_parser.ml"
               : 'distrib))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 114 "trs_parser.mly"
       ( [(1,_1)] )
# 653 "trs_parser.ml"
               : 'distrib0))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position * string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 115 "trs_parser.mly"
                    ( [(int_of_string (snd _1),_3)])
# 662 "trs_parser.ml"
               : 'distrib0))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'distrib0) in
    Obj.repr(
# 116 "trs_parser.mly"
                     ( (1,_1)::_3 )
# 670 "trs_parser.ml"
               : 'distrib0))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : Lexing.position * string) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : Lexing.position * string) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'distrib0) in
    Obj.repr(
# 117 "trs_parser.mly"
                                  ( (int_of_string (snd _1),_3)::_5 )
# 680 "trs_parser.ml"
               : 'distrib0))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'id) in
    Obj.repr(
# 120 "trs_parser.mly"
                          ( Term(_1,[]) )
# 687 "trs_parser.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'id) in
    Obj.repr(
# 121 "trs_parser.mly"
                          ( Term(_1,[]) )
# 694 "trs_parser.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : 'id) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'termlist) in
    Obj.repr(
# 122 "trs_parser.mly"
                          ( Term(_1,_3) )
# 702 "trs_parser.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 126 "trs_parser.mly"
                          ( [_1] )
# 709 "trs_parser.ml"
               : 'termlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'termlist) in
    Obj.repr(
# 127 "trs_parser.mly"
                          ( _1::_3 )
# 717 "trs_parser.ml"
               : 'termlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 131 "trs_parser.mly"
                               ( Innermost )
# 724 "trs_parser.ml"
               : 'strategydecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Lexing.position) in
    Obj.repr(
# 132 "trs_parser.mly"
                               ( Outermost )
# 731 "trs_parser.ml"
               : 'strategydecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Lexing.position) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'csstratlist) in
    Obj.repr(
# 133 "trs_parser.mly"
                               ( ContextSensitive(_2) )
# 739 "trs_parser.ml"
               : 'strategydecl))
; (fun __caml_parser_env ->
    Obj.repr(
# 137 "trs_parser.mly"
                     ( [] )
# 745 "trs_parser.ml"
               : 'csstratlist))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'id) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'intlist) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'csstratlist) in
    Obj.repr(
# 138 "trs_parser.mly"
                                   ( (_2,_3)::_5 )
# 754 "trs_parser.ml"
               : 'csstratlist))
; (fun __caml_parser_env ->
    Obj.repr(
# 142 "trs_parser.mly"
                     ( [] )
# 760 "trs_parser.ml"
               : 'intlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'id) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'intlist) in
    Obj.repr(
# 143 "trs_parser.mly"
             ( 
    let (loc,id) = _1 in
    try let n = int_of_string id in (loc,n)::_2 
    with Failure "int_of_string" -> raise Parsing.Parse_error 
)
# 772 "trs_parser.ml"
               : 'intlist))
(* Entry spec *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let spec (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf :  Trs_ast.decl list )
